package com.example.projecttp2.dao.repository;

import com.example.projecttp2.dao.entities.product;
import org.springframework.data.jpa.repository.JpaRepository;

public interface productRrepository extends JpaRepository<product,Long> {

}
