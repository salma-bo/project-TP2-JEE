package com.example.projecttp2;

import com.example.projecttp2.dao.entities.product;
import com.example.projecttp2.dao.repository.productRrepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.List;

@SpringBootApplication
public class ProjectTp2Application implements CommandLineRunner {

    public static void main(String[] args) {
        SpringApplication.run(ProjectTp2Application.class, args);
    }
 private productRrepository prRepo ;
    @Override
    public void run(String... args) throws Exception {
        product p1=new product(123,"sas","this product is a product for nothing",120);
        product p2=new product(456,"pomade jaune","this product is a product for everything",60);
        prRepo.save(p1);
        prRepo.save(p2);

        List<product> listPro = prRepo.findAll();
        listPro.forEach(prl->{System.out.println(prl.toString());});

        p1.setPrice(100);

        prRepo.delete(p1);

        try{
            System.out.println(prRepo.findById(123l).get());
        }catch (Exception Ex){
            System.out.println("produit supprimer avec succes");
        }
    }
}
